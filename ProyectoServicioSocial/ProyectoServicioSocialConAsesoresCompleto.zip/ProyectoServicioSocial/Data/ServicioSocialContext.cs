﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using ProyectoServicioSocial.Models;
using Microsoft.AspNetCore.Identity;


namespace ProyectoServicioSocial.Data
{
    public partial class ServicioSocialContext : DbContext
    {
        public ServicioSocialContext()
        {
        }

        public ServicioSocialContext(DbContextOptions<ServicioSocialContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Alumno> Alumno { get; set; }
        public virtual DbSet<Asesorexterno> Asesorexterno { get; set; }
        public virtual DbSet<Asesorinterno> Asesorinterno { get; set; }
        public virtual DbSet<Generales> Generales { get; set; }
        public virtual DbSet<InstitucionReceptora> InstitucionReceptora { get; set; }
        public virtual DbSet<ReporteInicial> ReporteInicial { get; set; }
        public virtual DbSet<ReporteMensual> ReporteMensual { get; set; }
        public virtual DbSet<Responsableprograma> Responsableprograma { get; set; }
        public virtual DbSet<ServicioSocial> ServicioSocial { get; set; }
        public virtual DbSet<Solicitud> Solicitud { get; set; }
        public virtual DbSet<TipoUsuario> TipoUsuario { get; set; }
        public virtual DbSet<Usuarios> Usuarios { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=(localdb)\\MSSQLLocalDB;Initial Catalog=bd_servicio_social;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Alumno>(entity =>
            {
                entity.HasKey(e => e.Matricula)
                    .HasName("PK__alumno__0FB9FB4E249A44D1");

                entity.ToTable("alumno");

                entity.HasIndex(e => new { e.UsuariosUsername, e.UsuariosTipoUsuarioId })
                    .HasName("fk_alumno_usuarios1_idx");

                entity.Property(e => e.Matricula).ValueGeneratedNever();

                entity.Property(e => e.ApMaterno).HasMaxLength(55);

                entity.Property(e => e.ApPaterno).HasMaxLength(55);

                entity.Property(e => e.Calle).HasMaxLength(55);

                entity.Property(e => e.Carrera).HasMaxLength(55);

                entity.Property(e => e.CiudadOrigen)
                    .HasColumnName("Ciudad_origen")
                    .HasMaxLength(50);

                entity.Property(e => e.Colonia).HasMaxLength(55);

                entity.Property(e => e.Email).HasMaxLength(55);

                entity.Property(e => e.Foto).HasMaxLength(55);

                entity.Property(e => e.Grupo).HasMaxLength(2);

                entity.Property(e => e.Localidad).HasMaxLength(55);

                entity.Property(e => e.Nombre).HasMaxLength(55);

                entity.Property(e => e.Rfc)
                    .HasColumnName("RFC")
                    .HasMaxLength(10);

                entity.Property(e => e.TelefonoFijo).HasColumnName("Telefono_fijo");

                entity.Property(e => e.UsuariosTipoUsuarioId).HasColumnName("usuarios_tipo_usuario_id");

                entity.Property(e => e.UsuariosUsername)
                    .IsRequired()
                    .HasColumnName("usuarios_username")
                    .HasMaxLength(13);

                entity.HasOne(d => d.Usuarios)
                    .WithMany(p => p.Alumno)
                    .HasForeignKey(d => new { d.UsuariosUsername, d.UsuariosTipoUsuarioId })
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_alumno_usuarios1");
            });

            modelBuilder.Entity<Asesorexterno>(entity =>
            {
                entity.HasKey(e => e.Rfc)
                    .HasName("PK__asesorex__CAFFA85F55730C37");

                entity.ToTable("asesorexterno");

                entity.Property(e => e.Rfc)
                    .HasColumnName("RFC")
                    .HasMaxLength(10);

                entity.Property(e => e.ApMaterno).HasMaxLength(55);

                entity.Property(e => e.ApPaterno).HasMaxLength(55);

                entity.Property(e => e.Cargo).HasMaxLength(55);

                entity.Property(e => e.Email).HasMaxLength(55);

                entity.Property(e => e.Institucion).HasMaxLength(55);

                entity.Property(e => e.Nombre).HasMaxLength(55);

                entity.Property(e => e.ProgramaEstudio)
                    .HasColumnName("Programa_Estudio")
                    .HasMaxLength(55);
            });

            modelBuilder.Entity<Asesorinterno>(entity =>
            {
                entity.HasKey(e => e.Rfc)
                    .HasName("PK__asesorin__CAFFA85FDB081A8A");

                entity.ToTable("asesorinterno");

                entity.Property(e => e.Rfc)
                    .HasColumnName("RFC")
                    .HasMaxLength(10);

                entity.Property(e => e.ApMaterno).HasMaxLength(55);

                entity.Property(e => e.ApPaterno).HasMaxLength(55);

                entity.Property(e => e.Cargo).HasMaxLength(55);

                entity.Property(e => e.Email).HasMaxLength(55);

                entity.Property(e => e.Institucion).HasMaxLength(55);

                entity.Property(e => e.Nombre).HasMaxLength(55);

                entity.Property(e => e.ProgramaEstudio)
                    .HasColumnName("Programa_Estudio")
                    .HasMaxLength(55);
            });

            modelBuilder.Entity<Generales>(entity =>
            {
                entity.HasKey(e => e.IdGeneral)
                    .HasName("PK__generale__3B06C20D7BB5DA88");

                entity.ToTable("generales");

                entity.Property(e => e.IdGeneral)
                    .HasColumnName("id_general")
                    .ValueGeneratedNever();

                entity.Property(e => e.Area)
                    .HasColumnName("area")
                    .HasMaxLength(50);

                entity.Property(e => e.Departamento)
                    .HasColumnName("departamento")
                    .HasMaxLength(70);

                entity.Property(e => e.DescripcionCargo)
                    .HasColumnName("descripcion_cargo")
                    .HasMaxLength(70);

                entity.Property(e => e.NombreUniversidad)
                    .HasColumnName("nombre_universidad")
                    .HasMaxLength(70);

                entity.Property(e => e.RfcCoordinador)
                    .HasColumnName("RFC_coordinador")
                    .HasMaxLength(70);

                entity.Property(e => e.Unidad)
                    .HasColumnName("unidad")
                    .HasMaxLength(70);
            });

            modelBuilder.Entity<InstitucionReceptora>(entity =>
            {
                entity.HasKey(e => e.IdInstituto)
                    .HasName("PK__instituc__7584CDF51A026335");

                entity.ToTable("institucion_receptora");

                entity.Property(e => e.IdInstituto)
                    .HasColumnName("id_instituto")
                    .ValueGeneratedNever();

                entity.Property(e => e.Calle).HasMaxLength(55);

                entity.Property(e => e.Colonia).HasMaxLength(55);

                entity.Property(e => e.Email).HasMaxLength(55);

                entity.Property(e => e.Localidad).HasMaxLength(55);

                entity.Property(e => e.Nombre).HasMaxLength(55);

                entity.Property(e => e.Rfc)
                    .HasColumnName("RFC")
                    .HasMaxLength(10);
            });

            modelBuilder.Entity<ReporteInicial>(entity =>
            {
                entity.HasKey(e => new { e.IdReporte, e.ServicioSocialIdServicioSocial, e.ServicioSocialSolicitudIdSolicitud, e.ServicioSocialSolicitudAlumnoMatricula })
                    .HasName("PK__reporte___D8ED18D8DFE7F663");

                entity.ToTable("reporte_inicial");

                entity.HasIndex(e => new { e.ServicioSocialIdServicioSocial, e.ServicioSocialSolicitudIdSolicitud, e.ServicioSocialSolicitudAlumnoMatricula })
                    .HasName("fk_reporte_inicial_servicio_social1_idx");

                entity.Property(e => e.IdReporte).HasColumnName("id_reporte");

                entity.Property(e => e.ServicioSocialIdServicioSocial).HasColumnName("servicio_social_id_servicio_social");

                entity.Property(e => e.ServicioSocialSolicitudIdSolicitud).HasColumnName("servicio_social_solicitud_id_solicitud");

                entity.Property(e => e.ServicioSocialSolicitudAlumnoMatricula).HasColumnName("servicio_social_solicitud_alumno_Matricula");

                entity.Property(e => e.Asunto)
                    .HasColumnName("asunto")
                    .HasMaxLength(30);

                entity.Property(e => e.DescripcionHorario)
                    .HasColumnName("descripcion_horario")
                    .HasMaxLength(60);

                entity.Property(e => e.FechaReporte)
                    .HasColumnName("fecha_reporte")
                    .HasColumnType("date");

                entity.Property(e => e.NombreProyecto)
                    .HasColumnName("nombre_proyecto")
                    .HasMaxLength(50);

                entity.Property(e => e.PlaneacionMes1)
                    .HasColumnName("planeacion_mes_1")
                    .HasMaxLength(60);

                entity.Property(e => e.PlaneacionMes2)
                    .HasColumnName("planeacion_mes_2")
                    .HasMaxLength(60);

                entity.Property(e => e.PlaneacionMes3)
                    .HasColumnName("planeacion_mes_3")
                    .HasMaxLength(60);

                entity.Property(e => e.PlaneacionMes4)
                    .HasColumnName("planeacion_mes_4")
                    .HasMaxLength(60);

                entity.Property(e => e.PlaneacionMes5)
                    .HasColumnName("planeacion_mes_5")
                    .HasMaxLength(60);

                entity.Property(e => e.PlaneacionMes6)
                    .HasColumnName("planeacion_mes_6")
                    .HasMaxLength(60);

                entity.Property(e => e.PlaneacionMes7)
                    .HasColumnName("planeacion_mes_7")
                    .HasMaxLength(60);

                entity.Property(e => e.PlaneacionMes8)
                    .HasColumnName("planeacion_mes_8")
                    .HasMaxLength(60);

                entity.HasOne(d => d.ServicioSocial)
                    .WithMany(p => p.ReporteInicial)
                    .HasForeignKey(d => new { d.ServicioSocialIdServicioSocial, d.ServicioSocialSolicitudIdSolicitud, d.ServicioSocialSolicitudAlumnoMatricula })
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_reporte_inicial_servicio_social1");
            });

            modelBuilder.Entity<ReporteMensual>(entity =>
            {
                entity.HasKey(e => new { e.IdReporte, e.ServicioSocialIdServicioSocial, e.ServicioSocialSolicitudIdSolicitud, e.ServicioSocialSolicitudAlumnoMatricula })
                    .HasName("PK__reporte___D8ED18D8740D6233");

                entity.ToTable("reporte_mensual");

                entity.HasIndex(e => new { e.ServicioSocialIdServicioSocial, e.ServicioSocialSolicitudIdSolicitud, e.ServicioSocialSolicitudAlumnoMatricula })
                    .HasName("fk_reporte_mensual_servicio_social1_idx");

                entity.Property(e => e.IdReporte).HasColumnName("id_reporte");

                entity.Property(e => e.ServicioSocialIdServicioSocial).HasColumnName("servicio_social_id_servicio_social");

                entity.Property(e => e.ServicioSocialSolicitudIdSolicitud).HasColumnName("servicio_social_solicitud_id_solicitud");

                entity.Property(e => e.ServicioSocialSolicitudAlumnoMatricula).HasColumnName("servicio_social_solicitud_alumno_Matricula");

                entity.Property(e => e.Asunto)
                    .HasColumnName("asunto")
                    .HasMaxLength(30);

                entity.Property(e => e.Descripcion)
                    .HasColumnName("descripcion")
                    .HasMaxLength(500);

                entity.Property(e => e.FechaReporte)
                    .HasColumnName("fecha_reporte")
                    .HasColumnType("date");

                entity.Property(e => e.HorasReportadas).HasColumnName("horas_reportadas");

                entity.Property(e => e.NombreProyecto)
                    .HasColumnName("nombre_proyecto")
                    .HasMaxLength(50);

                entity.Property(e => e.PeriodoReportado)
                    .HasColumnName("periodo_reportado")
                    .HasMaxLength(30);

                entity.HasOne(d => d.ServicioSocial)
                    .WithMany(p => p.ReporteMensual)
                    .HasForeignKey(d => new { d.ServicioSocialIdServicioSocial, d.ServicioSocialSolicitudIdSolicitud, d.ServicioSocialSolicitudAlumnoMatricula })
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_reporte_mensual_servicio_social1");
            });

            modelBuilder.Entity<Responsableprograma>(entity =>
            {
                entity.HasKey(e => e.Rfc)
                    .HasName("PK__responsa__CAFFA85F46FDEF70");

                entity.ToTable("responsableprograma");

                entity.Property(e => e.Rfc)
                    .HasColumnName("RFC")
                    .HasMaxLength(10);

                entity.Property(e => e.ApMaterno).HasMaxLength(55);

                entity.Property(e => e.ApPaterno).HasMaxLength(55);

                entity.Property(e => e.Cargo).HasMaxLength(55);

                entity.Property(e => e.Email).HasMaxLength(55);

                entity.Property(e => e.Institucion).HasMaxLength(55);

                entity.Property(e => e.Nombre).HasMaxLength(55);

                entity.Property(e => e.ProgramaEstudio)
                    .HasColumnName("Programa_Estudio")
                    .HasMaxLength(55);
            });

            modelBuilder.Entity<ServicioSocial>(entity =>
            {
                entity.HasKey(e => new { e.IdServicioSocial, e.SolicitudIdSolicitud, e.SolicitudAlumnoMatricula })
                    .HasName("PK__servicio__E175DA17D2D5C38E");

                entity.ToTable("servicio_social");

                entity.HasIndex(e => e.AsesorRfc)
                    .HasName("fk_servicio_social_asesor1_idx");

                entity.HasIndex(e => e.AsesorexternoRfc)
                    .HasName("fk_servicio_social_asesorexterno1_idx");

                entity.HasIndex(e => e.GeneralesIdGeneral)
                    .HasName("fk_servicio_social_generales1_idx");

                entity.HasIndex(e => e.ResponsableprogramaRfc)
                    .HasName("fk_servicio_social_responsableprograma1_idx");

                entity.HasIndex(e => new { e.SolicitudIdSolicitud, e.SolicitudAlumnoMatricula })
                    .HasName("fk_servicio_social_solicitud1_idx");

                entity.Property(e => e.IdServicioSocial).HasColumnName("id_servicio_social");

                entity.Property(e => e.SolicitudIdSolicitud).HasColumnName("solicitud_id_solicitud");

                entity.Property(e => e.SolicitudAlumnoMatricula).HasColumnName("solicitud_alumno_Matricula");

                entity.Property(e => e.AsesorRfc)
                    .IsRequired()
                    .HasColumnName("asesor_RFC")
                    .HasMaxLength(10);

                entity.Property(e => e.AsesorexternoRfc)
                    .IsRequired()
                    .HasColumnName("asesorexterno_RFC")
                    .HasMaxLength(10);

                entity.Property(e => e.Creditos).HasColumnName("creditos");

                entity.Property(e => e.Estatus)
                    .HasColumnName("estatus")
                    .HasMaxLength(20);

                entity.Property(e => e.FechaInicioServicio)
                    .HasColumnName("fecha_inicio_servicio")
                    .HasColumnType("date");

                entity.Property(e => e.GeneralesIdGeneral).HasColumnName("generales_id_general");

                entity.Property(e => e.ResponsableprogramaRfc)
                    .IsRequired()
                    .HasColumnName("responsableprograma_RFC")
                    .HasMaxLength(10);

                entity.HasOne(d => d.AsesorRfcNavigation)
                    .WithMany(p => p.ServicioSocial)
                    .HasForeignKey(d => d.AsesorRfc)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_servicio_social_asesor1");

                entity.HasOne(d => d.AsesorexternoRfcNavigation)
                    .WithMany(p => p.ServicioSocial)
                    .HasForeignKey(d => d.AsesorexternoRfc)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_servicio_social_asesorexterno1");

                entity.HasOne(d => d.GeneralesIdGeneralNavigation)
                    .WithMany(p => p.ServicioSocial)
                    .HasForeignKey(d => d.GeneralesIdGeneral)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_servicio_social_generales1");

                entity.HasOne(d => d.ResponsableprogramaRfcNavigation)
                    .WithMany(p => p.ServicioSocial)
                    .HasForeignKey(d => d.ResponsableprogramaRfc)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_servicio_social_responsableprograma1");

                entity.HasOne(d => d.Solicitud)
                    .WithMany(p => p.ServicioSocial)
                    .HasForeignKey(d => new { d.SolicitudIdSolicitud, d.SolicitudAlumnoMatricula })
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_servicio_social_solicitud1");
            });

            modelBuilder.Entity<Solicitud>(entity =>
            {
                entity.HasKey(e => new { e.IdSolicitud, e.AlumnoMatricula })
                    .HasName("PK__solicitu__854440734F367255");

                entity.ToTable("solicitud");

                entity.HasIndex(e => e.AlumnoMatricula)
                    .HasName("fk_solicitud_alumno1_idx");

                entity.HasIndex(e => e.InstitucionReceptoraIdInstituto)
                    .HasName("fk_solicitud_institucion_receptora1_idx");

                entity.Property(e => e.IdSolicitud).HasColumnName("id_solicitud");

                entity.Property(e => e.AlumnoMatricula).HasColumnName("alumno_Matricula");

                entity.Property(e => e.Estatus)
                    .HasColumnName("estatus")
                    .HasMaxLength(20);

                entity.Property(e => e.FechaSolicitud)
                    .HasColumnName("fecha_solicitud")
                    .HasColumnType("date");

                entity.Property(e => e.InstitucionReceptoraIdInstituto).HasColumnName("institucion_receptora_id_instituto");

                entity.HasOne(d => d.AlumnoMatriculaNavigation)
                    .WithMany(p => p.Solicitud)
                    .HasForeignKey(d => d.AlumnoMatricula)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_solicitud_alumno1");

                entity.HasOne(d => d.InstitucionReceptoraIdInstitutoNavigation)
                    .WithMany(p => p.Solicitud)
                    .HasForeignKey(d => d.InstitucionReceptoraIdInstituto)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_solicitud_institucion_receptora1");
            });

            modelBuilder.Entity<TipoUsuario>(entity =>
            {
                entity.ToTable("tipo_usuario");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Name).HasMaxLength(255);
            });

            modelBuilder.Entity<Usuarios>(entity =>
            {
                entity.HasKey(e => new { e.UserName, e.TipoUsuarioId })
                    .HasName("PK__usuarios__C50D2684E9908E13");

                entity.ToTable("usuarios");

                entity.HasIndex(e => e.TipoUsuarioId)
                    .HasName("fk_usuarios_tipo_usuario1_idx");

                entity.Property(e => e.UserName).HasMaxLength(13);

                entity.Property(e => e.TipoUsuarioId).HasColumnName("tipo_usuario_id");

                entity.Property(e => e.Email).HasMaxLength(80);

                entity.Property(e => e.Id)
                    .IsRequired()
                    .HasMaxLength(80);

                entity.Property(e => e.PasswordHash)
                    .IsRequired()
                    .HasMaxLength(45);

                entity.HasOne(d => d.TipoUsuario)
                    .WithMany(p => p.Usuarios)
                    .HasForeignKey(d => d.TipoUsuarioId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_usuarios_tipo_usuario1");
            });

            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<IdentityUser>().ToTable("Usuarios").Property(p => p.Id).HasColumnName("Id");
            modelBuilder.Entity<IdentityRole>().ToTable("TipoUsuario").Property(p => p.Id).HasColumnName("Id");


            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
