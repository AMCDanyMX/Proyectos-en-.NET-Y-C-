﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ProyectoServicioSocial.Data;
using ProyectoServicioSocial.Models;

namespace ProyectoServicioSocial.Controllers
{
    public class AsesorinternoesController : Controller
    {
        private readonly ServicioSocialContext _context;

        public AsesorinternoesController(ServicioSocialContext context)
        {
            _context = context;
        }

        // GET: Asesorinternoes
        public async Task<IActionResult> Index()
        {
            return View(await _context.Asesorinterno.ToListAsync());
        }

        // GET: Asesorinternoes/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var asesorinterno = await _context.Asesorinterno
                .FirstOrDefaultAsync(m => m.Rfc == id);
            if (asesorinterno == null)
            {
                return NotFound();
            }

            return View(asesorinterno);
        }

        // GET: Asesorinternoes/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Asesorinternoes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Nombre,ApPaterno,ApMaterno,Rfc,Institucion,Cargo,ProgramaEstudio,Telefono,Email")] Asesorinterno asesorinterno)
        {
            if (ModelState.IsValid)
            {
                _context.Add(asesorinterno);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(asesorinterno);
        }

        // GET: Asesorinternoes/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var asesorinterno = await _context.Asesorinterno.FindAsync(id);
            if (asesorinterno == null)
            {
                return NotFound();
            }
            return View(asesorinterno);
        }

        // POST: Asesorinternoes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("Nombre,ApPaterno,ApMaterno,Rfc,Institucion,Cargo,ProgramaEstudio,Telefono,Email")] Asesorinterno asesorinterno)
        {
            if (id != asesorinterno.Rfc)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(asesorinterno);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AsesorinternoExists(asesorinterno.Rfc))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(asesorinterno);
        }

        // GET: Asesorinternoes/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var asesorinterno = await _context.Asesorinterno
                .FirstOrDefaultAsync(m => m.Rfc == id);
            if (asesorinterno == null)
            {
                return NotFound();
            }

            return View(asesorinterno);
        }

        // POST: Asesorinternoes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var asesorinterno = await _context.Asesorinterno.FindAsync(id);
            _context.Asesorinterno.Remove(asesorinterno);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AsesorinternoExists(string id)
        {
            return _context.Asesorinterno.Any(e => e.Rfc == id);
        }
    }
}
