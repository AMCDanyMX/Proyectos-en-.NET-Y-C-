﻿using System;
using System.Collections.Generic;

namespace ProyectoServicioSocial.Models
{
    public partial class Alumno
    {
        public Alumno()
        {
            Solicitud = new HashSet<Solicitud>();
        }

        public int Matricula { get; set; }
        public string Nombre { get; set; }
        public string ApPaterno { get; set; }
        public string ApMaterno { get; set; }
        public string Rfc { get; set; }
        public string Carrera { get; set; }
        public int? Semestre { get; set; }
        public string Grupo { get; set; }
        public int? Telefono { get; set; }
        public int? TelefonoFijo { get; set; }
        public string Calle { get; set; }
        public int? Numero { get; set; }
        public string Colonia { get; set; }
        public string Localidad { get; set; }
        public int? CodigoPostal { get; set; }
        public string Email { get; set; }
        public string CiudadOrigen { get; set; }
        public string Foto { get; set; }
        public string UsuariosUsername { get; set; }
        public int UsuariosTipoUsuarioId { get; set; }

        public virtual Usuarios Usuarios { get; set; }
        public virtual ICollection<Solicitud> Solicitud { get; set; }
    }
}
