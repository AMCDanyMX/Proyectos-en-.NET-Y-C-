﻿using System;
using System.Collections.Generic;

namespace ProyectoServicioSocial.Models
{
    public partial class Generales
    {
        public Generales()
        {
            ServicioSocial = new HashSet<ServicioSocial>();
        }

        public int IdGeneral { get; set; }
        public string NombreUniversidad { get; set; }
        public string Area { get; set; }
        public string Unidad { get; set; }
        public string Departamento { get; set; }
        public string RfcCoordinador { get; set; }
        public string DescripcionCargo { get; set; }

        public virtual ICollection<ServicioSocial> ServicioSocial { get; set; }
    }
}
