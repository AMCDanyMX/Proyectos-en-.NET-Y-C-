﻿using System;
using System.Collections.Generic;

namespace ProyectoServicioSocial.Models
{
    public partial class Asesorexterno
    {
        public Asesorexterno()
        {
            ServicioSocial = new HashSet<ServicioSocial>();
        }

        public string Nombre { get; set; }
        public string ApPaterno { get; set; }
        public string ApMaterno { get; set; }
        public string Rfc { get; set; }
        public string Institucion { get; set; }
        public string Cargo { get; set; }
        public string ProgramaEstudio { get; set; }
        public int? Telefono { get; set; }
        public string Email { get; set; }

        public virtual ICollection<ServicioSocial> ServicioSocial { get; set; }
    }
}
