﻿using System;
using System.Collections.Generic;

namespace ProyectoServicioSocial.Models
{
    public partial class ServicioSocial
    {
        public ServicioSocial()
        {
            ReporteInicial = new HashSet<ReporteInicial>();
            ReporteMensual = new HashSet<ReporteMensual>();
        }

        public int IdServicioSocial { get; set; }
        public DateTime? FechaInicioServicio { get; set; }
        public int? Creditos { get; set; }
        public string Estatus { get; set; }
        public int SolicitudIdSolicitud { get; set; }
        public int SolicitudAlumnoMatricula { get; set; }
        public string AsesorRfc { get; set; }
        public string AsesorexternoRfc { get; set; }
        public string ResponsableprogramaRfc { get; set; }
        public int GeneralesIdGeneral { get; set; }

        public virtual Asesorinterno AsesorRfcNavigation { get; set; }
        public virtual Asesorexterno AsesorexternoRfcNavigation { get; set; }
        public virtual Generales GeneralesIdGeneralNavigation { get; set; }
        public virtual Responsableprograma ResponsableprogramaRfcNavigation { get; set; }
        public virtual Solicitud Solicitud { get; set; }
        public virtual ICollection<ReporteInicial> ReporteInicial { get; set; }
        public virtual ICollection<ReporteMensual> ReporteMensual { get; set; }
    }
}
