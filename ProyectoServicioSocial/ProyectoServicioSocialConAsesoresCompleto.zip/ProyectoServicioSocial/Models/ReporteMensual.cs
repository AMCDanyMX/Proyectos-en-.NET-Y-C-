﻿using System;
using System.Collections.Generic;

namespace ProyectoServicioSocial.Models
{
    public partial class ReporteMensual
    {
        public int IdReporte { get; set; }
        public DateTime? FechaReporte { get; set; }
        public string Asunto { get; set; }
        public string PeriodoReportado { get; set; }
        public int? HorasReportadas { get; set; }
        public string NombreProyecto { get; set; }
        public string Descripcion { get; set; }
        public int ServicioSocialIdServicioSocial { get; set; }
        public int ServicioSocialSolicitudIdSolicitud { get; set; }
        public int ServicioSocialSolicitudAlumnoMatricula { get; set; }

        public virtual ServicioSocial ServicioSocial { get; set; }
    }
}
