﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Identity;

namespace ProyectoServicioSocial.Models
{
    public partial class Usuarios: IdentityUser
    {
        public Usuarios()
        {
            Alumno = new HashSet<Alumno>();
        }

        public override string Id { get; set; }
        public override string UserName { get; set; }
        public override string PasswordHash { get; set; }
        public override string Email { get; set; }
        [PersonalData]
        public int? Status { get; set; }
        public int TipoUsuarioId { get; set; }

        public virtual TipoUsuario TipoUsuario { get; set; }
        public virtual ICollection<Alumno> Alumno { get; set; }
    }
}
