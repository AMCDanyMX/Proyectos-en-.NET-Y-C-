﻿using System;
using System.Collections.Generic;

namespace ProyectoServicioSocial.Models
{
    public partial class InstitucionReceptora
    {
        public InstitucionReceptora()
        {
            Solicitud = new HashSet<Solicitud>();
        }

        public int IdInstituto { get; set; }
        public string Nombre { get; set; }
        public string Rfc { get; set; }
        public int? Telefono { get; set; }
        public string Calle { get; set; }
        public int? Numero { get; set; }
        public string Colonia { get; set; }
        public string Localidad { get; set; }
        public int? CodigoPosta { get; set; }
        public string Email { get; set; }

        public virtual ICollection<Solicitud> Solicitud { get; set; }
    }
}
