﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Identity;

namespace ProyectoServicioSocial.Models
{
    public partial class TipoUsuario: IdentityRole<int>
    {
        public TipoUsuario()
        {
            Usuarios = new HashSet<Usuarios>();
        }

        public override int Id { get; set; }
        public override string Name { get; set; }
        [PersonalData]
        public int? Status { get; set; }

        public virtual ICollection<Usuarios> Usuarios { get; set; }
    }
}
