﻿using System;
using System.Collections.Generic;

namespace ProyectoServicioSocial.Models
{
    public partial class Solicitud
    {
        public Solicitud()
        {
            ServicioSocial = new HashSet<ServicioSocial>();
        }

        public int IdSolicitud { get; set; }
        public DateTime? FechaSolicitud { get; set; }
        public string Estatus { get; set; }
        public int AlumnoMatricula { get; set; }
        public int InstitucionReceptoraIdInstituto { get; set; }

        public virtual Alumno AlumnoMatriculaNavigation { get; set; }
        public virtual InstitucionReceptora InstitucionReceptoraIdInstitutoNavigation { get; set; }
        public virtual ICollection<ServicioSocial> ServicioSocial { get; set; }
    }
}
