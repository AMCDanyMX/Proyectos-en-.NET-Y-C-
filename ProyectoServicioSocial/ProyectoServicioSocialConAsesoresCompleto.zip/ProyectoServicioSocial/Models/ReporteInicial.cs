﻿using System;
using System.Collections.Generic;

namespace ProyectoServicioSocial.Models
{
    public partial class ReporteInicial
    {
        public int IdReporte { get; set; }
        public DateTime? FechaReporte { get; set; }
        public string Asunto { get; set; }
        public string NombreProyecto { get; set; }
        public string PlaneacionMes1 { get; set; }
        public string PlaneacionMes2 { get; set; }
        public string PlaneacionMes3 { get; set; }
        public string PlaneacionMes4 { get; set; }
        public string PlaneacionMes5 { get; set; }
        public string PlaneacionMes6 { get; set; }
        public string PlaneacionMes7 { get; set; }
        public string PlaneacionMes8 { get; set; }
        public string DescripcionHorario { get; set; }
        public int ServicioSocialIdServicioSocial { get; set; }
        public int ServicioSocialSolicitudIdSolicitud { get; set; }
        public int ServicioSocialSolicitudAlumnoMatricula { get; set; }

        public virtual ServicioSocial ServicioSocial { get; set; }
    }
}
