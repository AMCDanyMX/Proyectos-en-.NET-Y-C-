﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace ProyectoServicioSocial.Migrations
{
    public partial class MigServicioSocial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "asesorexterno",
                columns: table => new
                {
                    RFC = table.Column<string>(maxLength: 10, nullable: false),
                    Nombre = table.Column<string>(maxLength: 55, nullable: true),
                    ApPaterno = table.Column<string>(maxLength: 55, nullable: true),
                    ApMaterno = table.Column<string>(maxLength: 55, nullable: true),
                    Institucion = table.Column<string>(maxLength: 55, nullable: true),
                    Cargo = table.Column<string>(maxLength: 55, nullable: true),
                    Programa_Estudio = table.Column<string>(maxLength: 55, nullable: true),
                    Telefono = table.Column<int>(nullable: true),
                    Email = table.Column<string>(maxLength: 55, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__asesorex__CAFFA85F55730C37", x => x.RFC);
                });

            migrationBuilder.CreateTable(
                name: "asesorinterno",
                columns: table => new
                {
                    RFC = table.Column<string>(maxLength: 10, nullable: false),
                    Nombre = table.Column<string>(maxLength: 55, nullable: true),
                    ApPaterno = table.Column<string>(maxLength: 55, nullable: true),
                    ApMaterno = table.Column<string>(maxLength: 55, nullable: true),
                    Institucion = table.Column<string>(maxLength: 55, nullable: true),
                    Cargo = table.Column<string>(maxLength: 55, nullable: true),
                    Programa_Estudio = table.Column<string>(maxLength: 55, nullable: true),
                    Telefono = table.Column<int>(nullable: true),
                    Email = table.Column<string>(maxLength: 55, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__asesorin__CAFFA85FDB081A8A", x => x.RFC);
                });

            migrationBuilder.CreateTable(
                name: "generales",
                columns: table => new
                {
                    id_general = table.Column<int>(nullable: false),
                    nombre_universidad = table.Column<string>(maxLength: 70, nullable: true),
                    area = table.Column<string>(maxLength: 50, nullable: true),
                    unidad = table.Column<string>(maxLength: 70, nullable: true),
                    departamento = table.Column<string>(maxLength: 70, nullable: true),
                    RFC_coordinador = table.Column<string>(maxLength: 70, nullable: true),
                    descripcion_cargo = table.Column<string>(maxLength: 70, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__generale__3B06C20D7BB5DA88", x => x.id_general);
                });

            migrationBuilder.CreateTable(
                name: "institucion_receptora",
                columns: table => new
                {
                    id_instituto = table.Column<int>(nullable: false),
                    Nombre = table.Column<string>(maxLength: 55, nullable: true),
                    RFC = table.Column<string>(maxLength: 10, nullable: true),
                    Telefono = table.Column<int>(nullable: true),
                    Calle = table.Column<string>(maxLength: 55, nullable: true),
                    Numero = table.Column<int>(nullable: true),
                    Colonia = table.Column<string>(maxLength: 55, nullable: true),
                    Localidad = table.Column<string>(maxLength: 55, nullable: true),
                    CodigoPosta = table.Column<int>(nullable: true),
                    Email = table.Column<string>(maxLength: 55, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__instituc__7584CDF51A026335", x => x.id_instituto);
                });

            migrationBuilder.CreateTable(
                name: "responsableprograma",
                columns: table => new
                {
                    RFC = table.Column<string>(maxLength: 10, nullable: false),
                    Nombre = table.Column<string>(maxLength: 55, nullable: true),
                    ApPaterno = table.Column<string>(maxLength: 55, nullable: true),
                    ApMaterno = table.Column<string>(maxLength: 55, nullable: true),
                    Institucion = table.Column<string>(maxLength: 55, nullable: true),
                    Cargo = table.Column<string>(maxLength: 55, nullable: true),
                    Programa_Estudio = table.Column<string>(maxLength: 55, nullable: true),
                    Telefono = table.Column<int>(nullable: true),
                    Email = table.Column<string>(maxLength: 55, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__responsa__CAFFA85F46FDEF70", x => x.RFC);
                });

            migrationBuilder.CreateTable(
                name: "tipo_usuario",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false),
                    NormalizedName = table.Column<string>(nullable: true),
                    ConcurrencyStamp = table.Column<string>(nullable: true),
                    Name = table.Column<string>(maxLength: 255, nullable: true),
                    Status = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tipo_usuario", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "usuarios",
                columns: table => new
                {
                    UserName = table.Column<string>(maxLength: 13, nullable: false),
                    tipo_usuario_id = table.Column<int>(nullable: false),
                    NormalizedUserName = table.Column<string>(nullable: true),
                    NormalizedEmail = table.Column<string>(nullable: true),
                    EmailConfirmed = table.Column<bool>(nullable: false),
                    SecurityStamp = table.Column<string>(nullable: true),
                    ConcurrencyStamp = table.Column<string>(nullable: true),
                    PhoneNumber = table.Column<string>(nullable: true),
                    PhoneNumberConfirmed = table.Column<bool>(nullable: false),
                    TwoFactorEnabled = table.Column<bool>(nullable: false),
                    LockoutEnd = table.Column<DateTimeOffset>(nullable: true),
                    LockoutEnabled = table.Column<bool>(nullable: false),
                    AccessFailedCount = table.Column<int>(nullable: false),
                    Id = table.Column<string>(maxLength: 80, nullable: false),
                    PasswordHash = table.Column<string>(maxLength: 45, nullable: false),
                    Email = table.Column<string>(maxLength: 80, nullable: true),
                    Status = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__usuarios__C50D2684E9908E13", x => new { x.UserName, x.tipo_usuario_id });
                    table.ForeignKey(
                        name: "fk_usuarios_tipo_usuario1",
                        column: x => x.tipo_usuario_id,
                        principalTable: "tipo_usuario",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "alumno",
                columns: table => new
                {
                    Matricula = table.Column<int>(nullable: false),
                    Nombre = table.Column<string>(maxLength: 55, nullable: true),
                    ApPaterno = table.Column<string>(maxLength: 55, nullable: true),
                    ApMaterno = table.Column<string>(maxLength: 55, nullable: true),
                    RFC = table.Column<string>(maxLength: 10, nullable: true),
                    Carrera = table.Column<string>(maxLength: 55, nullable: true),
                    Semestre = table.Column<int>(nullable: true),
                    Grupo = table.Column<string>(maxLength: 2, nullable: true),
                    Telefono = table.Column<int>(nullable: true),
                    Telefono_fijo = table.Column<int>(nullable: true),
                    Calle = table.Column<string>(maxLength: 55, nullable: true),
                    Numero = table.Column<int>(nullable: true),
                    Colonia = table.Column<string>(maxLength: 55, nullable: true),
                    Localidad = table.Column<string>(maxLength: 55, nullable: true),
                    CodigoPostal = table.Column<int>(nullable: true),
                    Email = table.Column<string>(maxLength: 55, nullable: true),
                    Ciudad_origen = table.Column<string>(maxLength: 50, nullable: true),
                    Foto = table.Column<string>(maxLength: 55, nullable: true),
                    usuarios_username = table.Column<string>(maxLength: 13, nullable: false),
                    usuarios_tipo_usuario_id = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__alumno__0FB9FB4E249A44D1", x => x.Matricula);
                    table.ForeignKey(
                        name: "fk_alumno_usuarios1",
                        columns: x => new { x.usuarios_username, x.usuarios_tipo_usuario_id },
                        principalTable: "usuarios",
                        principalColumns: new[] { "UserName", "tipo_usuario_id" },
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "solicitud",
                columns: table => new
                {
                    id_solicitud = table.Column<int>(nullable: false),
                    alumno_Matricula = table.Column<int>(nullable: false),
                    fecha_solicitud = table.Column<DateTime>(type: "date", nullable: true),
                    estatus = table.Column<string>(maxLength: 20, nullable: true),
                    institucion_receptora_id_instituto = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__solicitu__854440734F367255", x => new { x.id_solicitud, x.alumno_Matricula });
                    table.ForeignKey(
                        name: "fk_solicitud_alumno1",
                        column: x => x.alumno_Matricula,
                        principalTable: "alumno",
                        principalColumn: "Matricula",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_solicitud_institucion_receptora1",
                        column: x => x.institucion_receptora_id_instituto,
                        principalTable: "institucion_receptora",
                        principalColumn: "id_instituto",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "servicio_social",
                columns: table => new
                {
                    id_servicio_social = table.Column<int>(nullable: false),
                    solicitud_id_solicitud = table.Column<int>(nullable: false),
                    solicitud_alumno_Matricula = table.Column<int>(nullable: false),
                    fecha_inicio_servicio = table.Column<DateTime>(type: "date", nullable: true),
                    creditos = table.Column<int>(nullable: true),
                    estatus = table.Column<string>(maxLength: 20, nullable: true),
                    asesor_RFC = table.Column<string>(maxLength: 10, nullable: false),
                    asesorexterno_RFC = table.Column<string>(maxLength: 10, nullable: false),
                    responsableprograma_RFC = table.Column<string>(maxLength: 10, nullable: false),
                    generales_id_general = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__servicio__E175DA17D2D5C38E", x => new { x.id_servicio_social, x.solicitud_id_solicitud, x.solicitud_alumno_Matricula });
                    table.ForeignKey(
                        name: "fk_servicio_social_asesor1",
                        column: x => x.asesor_RFC,
                        principalTable: "asesorinterno",
                        principalColumn: "RFC",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_servicio_social_asesorexterno1",
                        column: x => x.asesorexterno_RFC,
                        principalTable: "asesorexterno",
                        principalColumn: "RFC",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_servicio_social_generales1",
                        column: x => x.generales_id_general,
                        principalTable: "generales",
                        principalColumn: "id_general",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_servicio_social_responsableprograma1",
                        column: x => x.responsableprograma_RFC,
                        principalTable: "responsableprograma",
                        principalColumn: "RFC",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_servicio_social_solicitud1",
                        columns: x => new { x.solicitud_id_solicitud, x.solicitud_alumno_Matricula },
                        principalTable: "solicitud",
                        principalColumns: new[] { "id_solicitud", "alumno_Matricula" },
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "reporte_inicial",
                columns: table => new
                {
                    id_reporte = table.Column<int>(nullable: false),
                    servicio_social_id_servicio_social = table.Column<int>(nullable: false),
                    servicio_social_solicitud_id_solicitud = table.Column<int>(nullable: false),
                    servicio_social_solicitud_alumno_Matricula = table.Column<int>(nullable: false),
                    fecha_reporte = table.Column<DateTime>(type: "date", nullable: true),
                    asunto = table.Column<string>(maxLength: 30, nullable: true),
                    nombre_proyecto = table.Column<string>(maxLength: 50, nullable: true),
                    planeacion_mes_1 = table.Column<string>(maxLength: 60, nullable: true),
                    planeacion_mes_2 = table.Column<string>(maxLength: 60, nullable: true),
                    planeacion_mes_3 = table.Column<string>(maxLength: 60, nullable: true),
                    planeacion_mes_4 = table.Column<string>(maxLength: 60, nullable: true),
                    planeacion_mes_5 = table.Column<string>(maxLength: 60, nullable: true),
                    planeacion_mes_6 = table.Column<string>(maxLength: 60, nullable: true),
                    planeacion_mes_7 = table.Column<string>(maxLength: 60, nullable: true),
                    planeacion_mes_8 = table.Column<string>(maxLength: 60, nullable: true),
                    descripcion_horario = table.Column<string>(maxLength: 60, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__reporte___D8ED18D8DFE7F663", x => new { x.id_reporte, x.servicio_social_id_servicio_social, x.servicio_social_solicitud_id_solicitud, x.servicio_social_solicitud_alumno_Matricula });
                    table.ForeignKey(
                        name: "fk_reporte_inicial_servicio_social1",
                        columns: x => new { x.servicio_social_id_servicio_social, x.servicio_social_solicitud_id_solicitud, x.servicio_social_solicitud_alumno_Matricula },
                        principalTable: "servicio_social",
                        principalColumns: new[] { "id_servicio_social", "solicitud_id_solicitud", "solicitud_alumno_Matricula" },
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "reporte_mensual",
                columns: table => new
                {
                    id_reporte = table.Column<int>(nullable: false),
                    servicio_social_id_servicio_social = table.Column<int>(nullable: false),
                    servicio_social_solicitud_id_solicitud = table.Column<int>(nullable: false),
                    servicio_social_solicitud_alumno_Matricula = table.Column<int>(nullable: false),
                    fecha_reporte = table.Column<DateTime>(type: "date", nullable: true),
                    asunto = table.Column<string>(maxLength: 30, nullable: true),
                    periodo_reportado = table.Column<string>(maxLength: 30, nullable: true),
                    horas_reportadas = table.Column<int>(nullable: true),
                    nombre_proyecto = table.Column<string>(maxLength: 50, nullable: true),
                    descripcion = table.Column<string>(maxLength: 500, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__reporte___D8ED18D8740D6233", x => new { x.id_reporte, x.servicio_social_id_servicio_social, x.servicio_social_solicitud_id_solicitud, x.servicio_social_solicitud_alumno_Matricula });
                    table.ForeignKey(
                        name: "fk_reporte_mensual_servicio_social1",
                        columns: x => new { x.servicio_social_id_servicio_social, x.servicio_social_solicitud_id_solicitud, x.servicio_social_solicitud_alumno_Matricula },
                        principalTable: "servicio_social",
                        principalColumns: new[] { "id_servicio_social", "solicitud_id_solicitud", "solicitud_alumno_Matricula" },
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "fk_alumno_usuarios1_idx",
                table: "alumno",
                columns: new[] { "usuarios_username", "usuarios_tipo_usuario_id" });

            migrationBuilder.CreateIndex(
                name: "fk_reporte_inicial_servicio_social1_idx",
                table: "reporte_inicial",
                columns: new[] { "servicio_social_id_servicio_social", "servicio_social_solicitud_id_solicitud", "servicio_social_solicitud_alumno_Matricula" });

            migrationBuilder.CreateIndex(
                name: "fk_reporte_mensual_servicio_social1_idx",
                table: "reporte_mensual",
                columns: new[] { "servicio_social_id_servicio_social", "servicio_social_solicitud_id_solicitud", "servicio_social_solicitud_alumno_Matricula" });

            migrationBuilder.CreateIndex(
                name: "fk_servicio_social_asesor1_idx",
                table: "servicio_social",
                column: "asesor_RFC");

            migrationBuilder.CreateIndex(
                name: "fk_servicio_social_asesorexterno1_idx",
                table: "servicio_social",
                column: "asesorexterno_RFC");

            migrationBuilder.CreateIndex(
                name: "fk_servicio_social_generales1_idx",
                table: "servicio_social",
                column: "generales_id_general");

            migrationBuilder.CreateIndex(
                name: "fk_servicio_social_responsableprograma1_idx",
                table: "servicio_social",
                column: "responsableprograma_RFC");

            migrationBuilder.CreateIndex(
                name: "fk_servicio_social_solicitud1_idx",
                table: "servicio_social",
                columns: new[] { "solicitud_id_solicitud", "solicitud_alumno_Matricula" });

            migrationBuilder.CreateIndex(
                name: "fk_solicitud_alumno1_idx",
                table: "solicitud",
                column: "alumno_Matricula");

            migrationBuilder.CreateIndex(
                name: "fk_solicitud_institucion_receptora1_idx",
                table: "solicitud",
                column: "institucion_receptora_id_instituto");

            migrationBuilder.CreateIndex(
                name: "fk_usuarios_tipo_usuario1_idx",
                table: "usuarios",
                column: "tipo_usuario_id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "reporte_inicial");

            migrationBuilder.DropTable(
                name: "reporte_mensual");

            migrationBuilder.DropTable(
                name: "servicio_social");

            migrationBuilder.DropTable(
                name: "asesorinterno");

            migrationBuilder.DropTable(
                name: "asesorexterno");

            migrationBuilder.DropTable(
                name: "generales");

            migrationBuilder.DropTable(
                name: "responsableprograma");

            migrationBuilder.DropTable(
                name: "solicitud");

            migrationBuilder.DropTable(
                name: "alumno");

            migrationBuilder.DropTable(
                name: "institucion_receptora");

            migrationBuilder.DropTable(
                name: "usuarios");

            migrationBuilder.DropTable(
                name: "tipo_usuario");
        }
    }
}
